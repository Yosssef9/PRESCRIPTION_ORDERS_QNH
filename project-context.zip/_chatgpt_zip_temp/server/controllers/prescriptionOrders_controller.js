const service = require("../services/prescriptionOrders_service");
async function getPatientByCode(req, res, next) {
  try {
    const { patientCode } = req.params;
    const data = await service.getPatientByCode(patientCode);
    if (!data) {
      return res.status(404).json({ message: "Patient not found" });
    }
    res.json(data);
  } catch (error) {
    next(error);
  }
}
async function getSections(req, res, next) {
  try {
    const data = await service.getSections();
    if (!data) {
      return res.status(404).json({ message: "No Sections Found" });
    }
    res.json(data);
  } catch (error) {
    next(error);
  }
}
async function searchOrders(req, res, next) {
  try {
    let {
      patientCode = "",
      dateFrom = "",
      dateTo = "",
      sections = [],
      page = 1,
      pageSize = 10,
      sortBy = "",
      sortDirection = "desc",
    } = req.query;

    patientCode = patientCode.trim();

    if (!Array.isArray(sections)) {
      sections = sections ? [sections] : [];
    }

    sections = sections
      .map((section) => String(section).trim())
      .filter(Boolean);

    page = Number(page) || 1;
    pageSize = Number(pageSize) || 10;

    sortBy = String(sortBy).trim();
    sortDirection = String(sortDirection).toLowerCase();

    if (!["asc", "desc"].includes(sortDirection)) {
      sortDirection = "desc";
    }

    const hasPatientCode = !!patientCode;
    const hasFromDate = !!dateFrom;
    const hasToDate = !!dateTo;

    if (!hasPatientCode && !hasFromDate) {
      return res.status(400).json({
        message:
          "Please enter Patient Code, or choose From Date with at least one Section before searching.",
      });
    }

    if (!hasFromDate && hasToDate) {
      return res.status(400).json({
        message: "From Date is required when To Date is entered.",
      });
    }

    if (hasFromDate && !hasToDate) {
      dateTo = new Date().toISOString().split("T")[0];
    }

    const result = await service.searchOrders({
      patientCode,
      dateFrom,
      dateTo,
      sections,
      pageNumber: page,
      pageSize,
      sortBy,
      sortDirection,
    });

    const totalPages = Math.ceil(result.totalCount / pageSize);

    res.json({
      data: result.data,
      pagination: {
        page,
        pageSize,
        total: result.totalCount,
        totalPages,
        hasNext: page < totalPages,
      },
    });
  } catch (error) {
    next(error);
  }
}
async function getOrderByNo(req, res, next) {
  try {
    const { orderNo } = req.params;
    const data = await service.getOrderByNo(orderNo);

    if (!data) {
      return res.status(404).json({ message: "Order not found." });
    }

    res.json(data);
  } catch (error) {
    next(error);
  }
}
async function getOrderDetails(req, res, next) {
  try {
    const { orderNo } = req.params;
    const data = await service.getOrderDetails(orderNo);
    res.json(data);
  } catch (error) {
    next(error);
  }
}
async function saveOrderItems(req, res, next) {
  try {
    const { orderNo } = req.params;
    const { selectedItems, userCode, password, notes } = req.body;
    const result = await service.saveOrderItems({
      orderNo,
      selectedItems,
      userCode,
      password,
      notes,
    });
    res.json(result);
  } catch (error) {
    next(error);
  }
}
async function syncOrdersFromOracle(req, res, next) {
  try {
    const result = await service.syncOrdersFromOracle();
    res.json(result);
  } catch (error) {
    next(error);
  }
}
async function searchOrdersReport(req, res, next) {
  try {
    let {
      patientCode = "",
      dateFrom = "",
      dateTo = "",
      sections = [],
      orderNo = "",
      medicationCode = "",
      medicationName = "",
      actionDateFrom = "",
      actionDateTo = "",
      savedByCode = "",
      savedByName = "",
      page = 1,
      pageSize = 10,
      sortBy = "",
      sortDirection = "desc",
    } = req.query;

    // 🧠 normalize inputs
    patientCode = patientCode.trim();
    orderNo = orderNo.trim();
    medicationCode = medicationCode.trim();
    medicationName = medicationName.trim();
    savedByCode = savedByCode.trim();
    savedByName = savedByName.trim();

    page = Number(page) || 1;
    pageSize = Number(pageSize) || 10;

    sortBy = String(sortBy).trim();
    sortDirection = String(sortDirection).toLowerCase();

    if (!["asc", "desc"].includes(sortDirection)) {
      sortDirection = "desc";
    }

    if (!Array.isArray(sections)) {
      sections = sections ? [sections] : [];
    }

    sections = sections
      .map((section) => String(section).trim())
      .filter(Boolean);

    // 🔍 validation (keep your existing logic)
    const hasAnyFilter =
      !!patientCode ||
      sections.length > 0 ||
      !!orderNo ||
      !!medicationCode ||
      !!medicationName ||
      !!savedByCode ||
      !!savedByName ||
      !!dateFrom ||
      !!dateTo ||
      !!actionDateFrom ||
      !!actionDateTo;

    if (!hasAnyFilter) {
      return res.status(400).json({
        message: "Please enter at least one search filter.",
      });
    }

    if (!dateFrom && dateTo) {
      return res.status(400).json({
        message: "Order Date From is required when Order Date To is entered.",
      });
    }

    if (!actionDateFrom && actionDateTo) {
      return res.status(400).json({
        message: "Action Date From is required when Action Date To is entered.",
      });
    }

    if (dateFrom && !dateTo) {
      dateTo = new Date().toISOString().split("T")[0];
    }

    if (actionDateFrom && !actionDateTo) {
      actionDateTo = new Date().toISOString().split("T")[0];
    }

    // 🟢 call service WITH pagination + sorting
    const result = await service.searchOrdersReport({
      patientCode,
      dateFrom,
      dateTo,
      sections,
      orderNo,
      medicationCode,
      medicationName,
      actionDateFrom,
      actionDateTo,
      savedByCode,
      savedByName,
      pageNumber: page,
      pageSize,
      sortBy,
      sortDirection,
    });

    // 🟢 build pagination
    const totalPages = Math.ceil(result.totalCount / pageSize);

    res.json({
      data: result.data,
      pagination: {
        page,
        pageSize,
        total: result.totalCount,
        totalPages,
        hasNext: page < totalPages,
      },
    });
  } catch (error) {
    next(error);
  }
} 

module.exports = {
  getPatientByCode,
  searchOrders,
  getOrderDetails,
  getSections,
  saveOrderItems,
  getOrderByNo,
  syncOrdersFromOracle,
  searchOrdersReport,
};
