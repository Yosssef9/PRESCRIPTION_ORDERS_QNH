const { sql, getPool } = require("../config/db");
const spVerifyRecipientUser = require("./shared/spVerifyRecipientUser");
// =========================
// Patient by code
// SP_GET_PH_PAT_CODE_PrescriptionOrders
// =========================
async function spGetPatientByCode(patientCode) {
  const pool = await getPool();

  const result = await pool
    .request()
    .input("PATIENT_CODE", sql.VarChar(50), patientCode)
    .execute("SP_GET_PH_PAT_CODE_PrescriptionOrders");

  const row = result.recordset?.[0];
  if (!row) return null;

  return {
    patientCode: row.PATIENT_CODE || patientCode,
    patientName: row.PATIENT_NAME || row.PATIENT_NAME_EN || "",
  };
}

// =========================
// Sections
// SP_GET_PH_SECTIONS_PrescriptionOrders
// =========================
async function spGetSections() {
  const pool = await getPool();

  const result = await pool
    .request()
    .execute("SP_GET_PH_SECTIONS_PrescriptionOrders");

  return (result.recordset || []).map((row) => ({
    sectionName: row.SECTION_NAME || row.sectionName || "",
  }));
}

// =========================
// Orders table
// SP_GET_PH_PrescriptionOrders
// =========================
async function spSearchOrders({
  patientCode = null,
  dateFrom = null,
  dateTo = null,
  sections = [],
  orderNo = null,
  pageNumber = 1,
  pageSize = 10,
  sortBy = null,
  sortDirection = "desc",
}) {
  const pool = await getPool();
  const request = pool.request();

  request.input("PATIENT_CODE", sql.VarChar(50), patientCode || null);

  request.input(
    "SECTION_NAME",
    sql.VarChar(sql.MAX),
    Array.isArray(sections) && sections.length > 0 ? sections.join(",") : null,
  );

  request.input(
    "ORDER_DATE_FROM",
    sql.Date,
    dateFrom ? new Date(dateFrom) : null,
  );

  request.input("ORDER_DATE_TO", sql.Date, dateTo ? new Date(dateTo) : null);

  request.input("ORDER_NO", sql.VarChar(50), orderNo || null);

  // 🆕 pagination
  request.input("PAGE_NUMBER", sql.Int, pageNumber);
  request.input("PAGE_SIZE", sql.Int, pageSize);

  // 🆕 sorting
  request.input("SORT_BY", sql.NVarChar(50), sortBy || null);
  request.input("SORT_DIRECTION", sql.NVarChar(4), sortDirection || "desc");

  const result = await request.execute("SP_GET_PH_PrescriptionOrders");

  // 🟢 data
  const data = (result.recordsets[0] || []).map((row) => ({
    orderNo: row.ORDER_NO || "",
    orderDate: row.ORDER_DATE || "",
    patientCode: row.PATIENT_CODE || "",
    patientName: row.PATIENT_NAME || "",
    sectionName: row.SECTION_NAME || "",
    doctor: row.DOCTOR_NAME || "",
  }));

  // 🔵 total count
  const totalCount = result.recordsets[1]?.[0]?.TotalCount || 0;

  return {
    data,
    totalCount,
  };
}
// =========================
// Quick search by order no
// reuses SP_GET_PH_PrescriptionOrders
// =========================
async function spGetOrderByNo(orderNo) {
  const result = await spSearchOrders({
    patientCode: "",
    dateFrom: "",
    dateTo: "",
    sections: [],
    orderNo,
    pageNumber: 1,
    pageSize: 1,
  });

  return result.data?.[0] || null;
}

// =========================
// Order details
// SP_GET_PH_PrescriptionOrderDetails
// =========================
async function spGetOrderDetails(orderNo) {
  const pool = await getPool();

  const result = await pool
    .request()
    .input("ORDER_NO", sql.VarChar(50), orderNo)
    .execute("SP_GET_PH_PrescriptionOrderDetails");

  return (result.recordset || []).map((row) => ({
    id: `${row.ORDER_NO}-${row.SEQUENCE_NO}`,
    sequenceNo: row.SEQUENCE_NO,
    orderNo: row.ORDER_NO,
    orderDate: row.ORDER_DATE,
    medicationCode: row.MEDICATION_CODE,
    medicationName: row.MEDICATION_NAME,
    actionDate: row.PRESCRIPTION_ACTION_DATE || "-",
    endDate: row.PRESCRIPTION_END_DATE || "-",

    savedByUserCode: row.Recipient_code || null,
    savedByUserName: row.Recipient_name || null,
    savedAt: row.Recipient_at || null,
    notes: row.Notes || "",
  }));
}

// =========================
// Save recipient info
// SP_UPDATE_PH_PrescriptionOrderRecipient
// =========================
async function spSaveOrderItems({
  orderNo,
  selectedItems,
  userCode,
  password,
  notes,
}) {
  if (!Array.isArray(selectedItems) || selectedItems.length === 0) {
    const error = new Error("Please select at least one item.");
    error.statusCode = 400;
    throw error;
  }

  // 1) Verify user first
  const verifiedUser = await spVerifyRecipientUser(userCode, password);

  if (!verifiedUser) {
    const error = new Error("User code or password is incorrect.");
    error.statusCode = 401;
    throw error;
  }

  // 2) Load order details
  const details = await spGetOrderDetails(orderNo);

  if (!details.length) {
    const error = new Error("Order not found.");
    error.statusCode = 404;
    throw error;
  }

  // 3) Find selected rows
  const selectedRows = details.filter(
    (item) =>
      selectedItems.includes(item.id) || selectedItems.includes(item.itemCode),
  );

  if (!selectedRows.length) {
    const error = new Error("No valid items selected.");
    error.statusCode = 400;
    throw error;
  }

  // 4) Prevent re-saving rows already received
  const alreadySavedItems = selectedRows.filter(
    (item) => item.savedByUserCode || item.savedAt,
  );

  if (alreadySavedItems.length > 0) {
    const error = new Error(
      `These item(s) are already saved and cannot be saved again: ${alreadySavedItems
        .map((item) => item.itemCode)
        .join(", ")}`,
    );
    error.statusCode = 400;
    throw error;
  }

  // 5) Update each selected row
  const pool = await getPool();

  for (const row of selectedRows) {
    await pool
      .request()
      .input("SEQUENCE_NO", sql.Int, row.sequenceNo)
      .input("ORDER_NO", sql.VarChar(50), orderNo)
      .input("Recipient_code", sql.VarChar(50), verifiedUser.userCode)
      .input("Recipient_name", sql.VarChar(100), verifiedUser.userName)
      .input("Recipient_at", sql.DateTime, new Date())
      .input("Notes", sql.NVarChar(500), notes || null)
      .execute("SP_UPDATE_PH_PrescriptionOrderRecipient");
  }

  // 6) Reload fresh details
  const refreshedDetails = await spGetOrderDetails(orderNo);

  return {
    success: true,
    orderNo,
    savedCount: selectedRows.length,
    message: `Saved ${selectedRows.length} item(s) successfully.`,
    details: refreshedDetails,
  };
}

async function spSyncOrdersFromOracle() {
  const pool = await getPool();

  const result = await pool
    .request()
    .execute("SP_Insert_PH_PrescriptionOrders");

  const row = result.recordset?.[0] || {};

  return {
    success: true,
    insertedCount:
      row.INSERTED_COUNT ?? row.InsertedCount ?? row.insertedCount ?? 0,
    skippedCount:
      row.SKIPPED_COUNT ?? row.SkippedCount ?? row.skippedCount ?? 0,
    message:
      row.MESSAGE || row.Message || "Orders sync completed successfully.",
  };
}

async function spSearchOrdersReport({
  patientCode = null,
  dateFrom = null,
  dateTo = null,
  sections = [],
  orderNo = null,
  medicationCode = null,
  medicationName = null,
  actionDateFrom = null,
  actionDateTo = null,
  savedByCode = null,
  savedByName = null,
  pageNumber = 1,
  pageSize = 10,
  sortBy = null,
  sortDirection = "desc",
}) {
  const pool = await getPool();
  const request = pool.request();

  request.input("ORDER_NO", sql.NVarChar(50), orderNo || null);
  request.input("PATIENT_CODE", sql.NVarChar(50), patientCode || null);

  request.input(
    "SECTION_NAME",
    sql.NVarChar(sql.MAX),
    Array.isArray(sections) && sections.length > 0 ? sections.join(",") : null,
  );

  request.input("MEDICATION_CODE", sql.NVarChar(50), medicationCode || null);
  request.input("MEDICATION_NAME", sql.NVarChar(200), medicationName || null);

  request.input(
    "ORDER_DATE_FROM",
    sql.Date,
    dateFrom ? new Date(dateFrom) : null,
  );

  request.input("ORDER_DATE_TO", sql.Date, dateTo ? new Date(dateTo) : null);

  request.input(
    "PRESCRIPTION_ACTION_FROM",
    sql.Date,
    actionDateFrom ? new Date(actionDateFrom) : null,
  );

  request.input(
    "PRESCRIPTION_ACTION_TO",
    sql.Date,
    actionDateTo ? new Date(actionDateTo) : null,
  );

  request.input("Recipient_code", sql.NVarChar(50), savedByCode || null);
  request.input("Recipient_name", sql.NVarChar(200), savedByName || null);

  // 🆕 pagination
  request.input("PAGE_NUMBER", sql.Int, pageNumber);
  request.input("PAGE_SIZE", sql.Int, pageSize);

  // 🆕 sorting
  request.input("SORT_BY", sql.NVarChar(50), sortBy || null);
  request.input("SORT_DIRECTION", sql.NVarChar(4), sortDirection || "desc");

  const result = await request.execute(
    "SP_SEARCH_PH_PrescriptionOrders_Result",
  );

  const data = (result.recordsets[0] || []).map((row) => ({
    orderNo: row.ORDER_NO || "",
    orderDate: row.ORDER_DATE || "",
    doctor: row.DOCTOR_NAME || "",
    sectionName: row.SECTION_NAME || "",
    patientCode: row.PATIENT_CODE || "",
    patientName: row.PATIENT_NAME || "",
    medicationCode: row.MEDICATION_CODE || "",
    medicationName: row.MEDICATION_NAME || "",
    actionDate: row.PRESCRIPTION_ACTION_DATE || "",
    endDate: row.PRESCRIPTION_END_DATE || "",
    savedByCode: row.Recipient_code || "",
    savedByName: row.Recipient_name || "",
    savedAt: row.Recipient_at || "",
    notes: row.Notes || "",
  }));

  const totalCount = result.recordsets[1]?.[0]?.TotalCount || 0;

  return {
    data,
    totalCount,
  };
}

module.exports = {
  spGetPatientByCode,
  spGetSections,
  spSearchOrders,
  spGetOrderByNo,
  spGetOrderDetails,
  spSaveOrderItems,
  spSyncOrdersFromOracle,
  spSearchOrdersReport,
};
